<template>
    <div></div>
</template>

<script>
import axios from 'axios'; // 用于发送 HTTP 请求
import CryptoJS from 'crypto-js'; // 用于生成签名
import { v4 as uuidv4 } from 'uuid'; // 用于生成随机字符串

export default {
    name: 'AudioWebSocketService',
    data() {
        return {
            appId: '3032677197',
            appKey: 'qoDefbZxeZLUHaLV',
            domain: 'api-ai.vivo.com.cn',
            method: 'GET',
            uri: '/asr/v2',
            params: {
                client_version: encodeURIComponent('unknown'),
                package: encodeURIComponent('unknown'),
                sdk_version: encodeURIComponent('3.0'),
                user_id: encodeURIComponent('2addc42b7ae689dfdf1c63e220df52a2'),
                android_version: encodeURIComponent('unknown'),
                system_time: encodeURIComponent(new Date().getTime()),
                net_type: 1,
                nonce_str: encodeURIComponent(uuidv4()),
                engineid: 'longasrlisten'
            },
            ws: null // WebSocket 对象
        };
    },
    methods: {
        // 生成签名
        generateSignature() {
            const timestamp = Math.floor(Date.now() / 1000).toString();
            // console.log("timestamp: ", timestamp);
            const nonce = this.generateNonce();
            // console.log("nonce: ", nonce);
            const canonicalQueryString = this.generateCanonicalQueryString(this.params);
            // console.log("canonicalQueryString: ", canonicalQueryString);
            const signingString = `${this.method}\n${this.uri}\n${canonicalQueryString}\n${this.appId}\n${timestamp}\n`;
            // console.log("signingString: ", signingString);
            const signature = CryptoJS.enc.Base64.stringify(CryptoJS.HmacSHA256(signingString, this.appKey));
            // console.log("signature: ", signature);
            return {
                'X-AI-GATEWAY-APP-ID': this.appId,
                'X-AI-GATEWAY-TIMESTAMP': timestamp,
                'X-AI-GATEWAY-NONCE': nonce,
                'X-AI-GATEWAY-SIGNED-HEADERS': "x-ai-gateway-app-id;x-ai-gateway-timestamp;x-ai-gateway-nonce",
                'X-AI-GATEWAY-SIGNATURE': signature
            };
        },
        generateNonce(length = 8) {
            const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
            let nonce = '';
            for (let i = 0; i < length; i++) {
                nonce += chars[Math.floor(Math.random() * chars.length)];
            }
            return nonce;
        },
        // 生成规范化的查询字符串
        generateCanonicalQueryString(params) {
            const sortedParams = Object.keys(params).sort();
            const queryString = sortedParams.map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`).join('&');
            return queryString;
        },
        // 发送 WebSocket 消息
        sendMessage() {
            // 发送消息的逻辑
        },
        // 接收 WebSocket 消息
        receiveMessage() {
            // 接收消息的逻辑
        },
        // 连接 WebSocket
        connectWebSocket() {
            const headers = this.generateSignature();
            const queryString = this.generateCanonicalQueryString(this.params);
            const url = `http://${this.domain}${this.uri}?${queryString}`;
            console.log("url: ", url);
            console.log("headers: ", headers);

            // 使用 Axios 发送 HTTP 请求并添加请求头
            axios
                .get(url, { headers })
                .then(response => {
                    console.log("response: ", response);

                    // 在请求成功后创建 WebSocket 连接
                    this.ws = new WebSocket(response.request.responseURL);

                    // 处理 WebSocket 收到的消息
                    this.ws.onmessage = event => {
                        console.log('Received message:', event.data);
                    };

                    // 处理 WebSocket 错误
                    this.ws.onerror = error => {
                        console.error('WebSocket error:', error);
                    };

                    // 处理 WebSocket 关闭
                    this.ws.onclose = () => {
                        console.log('WebSocket closed');
                    };
                })
                .catch(error => {
                    console.error('Error:', error);
                });

            // this.ws = new WebSocket(url);
            // this.ws.onopen = () => {
            //     console.log('WebSocket connected');
            // };
            // this.ws.onmessage = event => {
            //     console.log('WebSocket message received:', event.data);
            // };
            // this.ws.onerror = error => {
            //     console.error('WebSocket error:', error);
            // };
            // this.ws.onclose = () => {
            //     console.log('WebSocket closed');
            // };
        }
    },
    created() {
        // this.connectWebSocket(); // 在组件创建时连接 WebSocket
    },
    beforeDestroy() {
        if (this.ws) {
            this.ws.close(); // 在组件销毁前关闭 WebSocket 连接
        }
    }
};
</script>

<style>
/* 这里是样式内容，可以根据需要添加 */
</style>
